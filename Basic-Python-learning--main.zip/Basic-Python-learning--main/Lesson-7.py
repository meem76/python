course_name = 'Learning Python Programming'

print(course_name.upper())

print(course_name.lower())

print(course_name.find('Program'))

print(course_name.replace('Learning','Typing'))

print('Python' in course_name)

print('programming' in course_name)

print(len(course_name))