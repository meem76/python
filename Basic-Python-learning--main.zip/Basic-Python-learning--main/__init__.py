'''

# __init__.py
# You can leave this file empty or import functions from modules for easier access
from .math_operations import add, subtract
from .string_operations import uppercase, lowercase

'''