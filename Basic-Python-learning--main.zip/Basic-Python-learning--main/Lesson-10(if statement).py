is_sunny = False
is_cold = False

if is_sunny:
    print('Carry an Umbrella.')

elif is_cold:
    print('No need to carry an Umbrella.')

else:
    print('Please check the weather.')
