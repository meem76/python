# string_operations.py
def uppercase(text):
    return text.upper()

def lowercase(text):
    return text.lower()