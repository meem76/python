name = "TANMAY DAS"
age = 23
age = 20
height = '5.8inc'
good_student = False

print(name)

print(age) #variable
print('age') #string

print(height)

print(good_student)