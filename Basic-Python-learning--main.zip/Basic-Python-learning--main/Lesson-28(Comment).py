#declare and initialize variables (this is called single line comment)
p = 12
q = 18

#add or sub p, q and print the results
print(p + q)  #addition
print(q - p)  #subtraction

#multiple hash for multiple line comment
#Python is a wonderful language.
#using this language we can create program easily.
#In our daily life, Python is very important and useful.
#Python is the easiest programming language than any other programming language.

'''
Triple quotes(''' ''')  for multiple line comment
Python is a wonderful language.
using this language we can create program easily.
In our daily life, Python is very important and useful.
Python is the easiest programming language than any other programming language.
'''

"""
Triple quotes(""" """)  for multiple line comment
Python is a wonderful language.
using this language we can create program easily.
In our daily life, Python is very important and useful.
Python is the easiest programming language than any other programming language.
"""
