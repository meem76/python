number_tuple = (2, 4, 6, 8)
add_num_tuple = number_tuple[0] + number_tuple[1] +number_tuple[2] + number_tuple[3]
print(add_num_tuple)

p = number_tuple[0]
q = number_tuple[1]
r = number_tuple[2]
s = number_tuple[3]
print(p + q + r + s)

a, b, c, d = number_tuple
print(a + b + c + d)

#converting into list replacing the brackets
number_tuple = [2, 4, 6, 8]
a, b, c, d = number_tuple
print(a + b + c + d)
