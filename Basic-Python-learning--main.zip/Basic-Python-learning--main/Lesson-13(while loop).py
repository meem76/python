i = 0

while i < 5:
    print(i)
    i += 1   #augmented assign operator

print('The while loop is closed!')