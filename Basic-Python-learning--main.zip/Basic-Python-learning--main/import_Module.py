#import_module.py ; Lesson-32
import main_Module

x = 10
y = 5

print("Addition:", main_Module.add(x, y))
print("Subtraction:", main_Module.subtract(x, y))
print("Multiplication:", main_Module.multiply(x, y))
print("Division:", main_Module.divide(x, y))
