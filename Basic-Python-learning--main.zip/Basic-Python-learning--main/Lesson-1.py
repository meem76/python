print("Happy New Year!")

print("Happy Holiday;")

print("I am a Student.")

print("*" * 15)