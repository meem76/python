course_name = 'Tanmay says, "I Love Python Programming!"'

print(course_name[0:-2])

print(course_name[0:11])

print(course_name[14:-14])

print(course_name[-13:-6])