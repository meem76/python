name = "TANMAY DAS"
code_name = "TD"

#TANMAY DAS (TD) is a lazy boy;
print(name+' ('+code_name+')' " is a lazy boy"+';')

message = name+' ('+code_name+')' " is a lazy boy"+';'
print(message)

print(f"{name} ({code_name}) is a lazy boy;")

message_1 = f"{name} ({code_name}) is a lazy boy;"
print(message_1)