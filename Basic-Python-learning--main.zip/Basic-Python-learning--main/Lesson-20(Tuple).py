number_tuple = (2, 4, 6, 8)

print(number_tuple)

print(number_tuple[2])

print(number_tuple.count(8))