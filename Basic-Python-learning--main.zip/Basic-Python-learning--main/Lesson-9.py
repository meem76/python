import math

print(math.ceil(8.6))

print(math.floor(6.7))

print(math.factorial(5))

print(round (5.5))

print(round (5.3))

print(round (4.6))

print(round (4.5))  #why?

print(round (4.4))

print(round (3.5))


print(abs (-3.9))