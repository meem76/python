print(10+10)

print(20-5)

print(10-20)

print(5*11)

print(5/3)   #floating point division

print(5//3)  #integer division

print(100/5) #quotient

print(5%3)   #for remainder

print(5**3)  #double asterisk means power

x = 10
x = x + 5   #complete expression
#0r
x += 5      #shorthand expression
print(x)

y = 20
y = y + 5   #complete expression
#0r
y += 5      #shorthand expression
print(y)

z = 5 + 4 * 3 ** 3
print(z)

p = (5 + 4) * 3 ** 3
print(p)

q = (5 + 4) * (3 + 2)
print(q)

s = (5 + 4) * (3 - 1)
print(s)