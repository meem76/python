name = input('What is your name? = ')
address = input('Where are you from? = ')

print(name)

print(address)

#concatenation
print(name+ ' lives in ' +address+'.')