for x in range(5):
    for y in range(5):
        print(f'({x} , {y})')
