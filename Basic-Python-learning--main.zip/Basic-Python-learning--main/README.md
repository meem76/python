# Basic-Python-learning-
def python():
   print("python is really fun.")
   return
