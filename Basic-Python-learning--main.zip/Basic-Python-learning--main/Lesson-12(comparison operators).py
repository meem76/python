price_potato = 12

if price_potato == 12:
    print('I will buy.')

if price_potato != 12:
    print("I won't buy.")

if price_potato > 12:
    print('It is too much high.')

if price_potato < 12:
    print('It is cheap.')

if price_potato >= 12:
    print('I will negotiate.')

if price_potato <= 12:
    print('It is reasonable.')
