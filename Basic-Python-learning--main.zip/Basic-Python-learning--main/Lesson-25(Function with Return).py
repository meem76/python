def add(number_1, number_2):
    return number_1 + number_2

result = add(4, 6)
print(result)

#without storing the values
print(add(4, 6))

#without 'return' = "none"
def add(number_1, number_2):
    number_1 + number_2

result = add(4, 6)
print(result)
